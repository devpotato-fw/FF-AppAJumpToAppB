//
//  Page1ViewController.m
//  App-B
//
//  Created by wangfang on 2017/8/19.
//  Copyright © 2017年 onefboy. All rights reserved.
//

#import "Page1ViewController.h"

@interface Page1ViewController ()

@end

@implementation Page1ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (IBAction)click:(id)sender {
  // 1.拿到对应应用程序的URL Scheme
  NSString *jumpbackString = [[self.urlString componentsSeparatedByString:@"?"] lastObject];
  NSString *urlSchemeString = [[jumpbackString componentsSeparatedByString:@"="] lastObject];
  NSString *urlString = [urlSchemeString stringByAppendingString:@"://"];
  
  // 2.获取对应应用程序的URL
  NSURL *url = [NSURL URLWithString:urlString];
  
  // 3.判断是否可以打开
  if ([[UIApplication sharedApplication] canOpenURL:url]) {
    [[UIApplication sharedApplication] openURL:url];
  }
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
