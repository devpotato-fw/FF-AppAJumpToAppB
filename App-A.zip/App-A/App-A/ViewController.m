//
//  ViewController.m
//  App-A
//
//  Created by wangfang on 2017/8/19.
//  Copyright © 2017年 onefboy. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
  [super viewDidLoad];
  // Do any additional setup after loading the view, typically from a nib.
}

// 打开AppB
- (IBAction)jumpToAppB:(id)sender {
  // 1.获取应用程序App-B的URL Scheme
  NSURL *appBUrl = [NSURL URLWithString:@"AppB://"];
  
  // 2.判断手机中是否安装了对应程序
  if ([[UIApplication sharedApplication] canOpenURL:appBUrl]) {
    // 3. 打开应用程序App-B
    [[UIApplication sharedApplication] openURL:appBUrl];
  } else {
    NSLog(@"没有安装");
  }
}

// 打开AppB，并打开指定页面Page1
- (IBAction)jumpToAppBPage1:(id)sender {
  // 1.获取应用程序App-B的Page1页面的URL
  NSURL *appBUrl = [NSURL URLWithString:@"AppB://Page1?jumpback=AppA"];
  
  // 2.判断手机中是否安装了对应程序
  if ([[UIApplication sharedApplication] canOpenURL:appBUrl]) {
    // 3. 打开应用程序App-B的Page1页面
    [[UIApplication sharedApplication] openURL:appBUrl];
  } else {
    NSLog(@"没有安装");
  }
}

// 打开AppB，并打开授权登录功能
- (IBAction)jumpToAppBThirdLogin:(id)sender {
  // 1.获取应用程序App-B的Page2页面的URL
  NSURL *appBUrl = [NSURL URLWithString:@"AppB://ThirdLogin?jumpback=AppA"];
  
  // 2.判断手机中是否安装了对应程序
  if ([[UIApplication sharedApplication] canOpenURL:appBUrl]) {
    // 3. 打开应用程序App-B的Page2页面
    [[UIApplication sharedApplication] openURL:appBUrl];
  } else {
    NSLog(@"没有安装");
  }
}

@end
