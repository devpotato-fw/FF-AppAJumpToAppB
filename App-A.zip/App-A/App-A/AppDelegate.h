//
//  AppDelegate.h
//  App-A
//
//  Created by wangfang on 2017/8/19.
//  Copyright © 2017年 onefboy. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

